/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          900: '#102A43',
        },
        brand: {
          blue: '#2563EB',
          teal: '#14B8A6',
          slate: '#1E293B',
          bg: '#F8FAFC',
        }
      },
      fontFamily: {
        sans: ['Manrope', 'Inter', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
