# InfoSure: Verify Before You Trust

InfoSure is a modern, professional EdTech and cybersecurity web application designed to help students identify potentially fraudulent educational offers, online courses, scholarships, internships, exam notifications, and job opportunities.

## 🚀 Quick Start (Local Development)

1. Clone or download this repository.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Run the development server:
   ```bash
   npm run dev
   ```
4. Open your browser at `http://localhost:5173`.

## 📦 Deployment on Vercel

1. Push this code to a GitHub repository.
2. Go to [Vercel](https://vercel.com/), click **Add New > Project**, and import your repository.
3. Vercel will auto-detect Vite. Click **Deploy**.

## 🛡️ Features
- **Information Verification Dashboard**: Analyze suspicious claims, URLs, and offers with transparent preliminary reports and official source checks.
- **Scam Awareness Learning Center**: Interactive quizzes, real-world fictional training scenarios, progress tracking, and beginner/intermediate difficulty levels.
- **User Dashboard**: Track analysis history, quiz scores, and saved reports in demo mode.
- **Professional SaaS Branding**: Deep navy blue, professional blue, and teal color palette with fully responsive design.
