import React, { useState } from 'react';
import { 
  ShieldCheck, Search, BookOpen, User, Menu, X, AlertTriangle, CheckCircle2, 
  HelpCircle, ExternalLink, ArrowRight, Award, FileText, Send, Lock, Mail, 
  RotateCcw, Sparkles, AlertOctagon, Check, Copy, Download, RefreshCw, ChevronRight
} from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'home' | 'verify' | 'result' | 'learn' | 'dashboard' | 'about' | 'contact' | 'signin'>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Verification Form State
  const [claimInput, setClaimInput] = useState('');
  const [urlInput, setUrlInput] = useState('');
  const [category, setCategory] = useState('Scholarship');
  const [description, setDescription] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);

  // Learning Quiz State
  const [selectedScenario, setSelectedScenario] = useState<number | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);
  const [difficulty, setDifficulty] = useState<'beginner' | 'intermediate'>('beginner');

  // Contact State
  const [contactSubmitted, setContactSubmitted] = useState(false);

  // Auth State
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    if (!claimInput.trim() && !urlInput.trim()) return;
    setIsAnalyzing(true);
    setTimeout(() => {
      setIsAnalyzing(false);
      // Determine simulated risk based on keywords
      const lower = (claimInput + urlInput).toLowerCase();
      let status = 'needs_verification';
      let title = 'Needs Further Verification';
      let color = 'amber';
      let indicators = [
        'Unverified domain registrar details or newly created website.',
        'Vague language requesting upfront processing fees or personal bank details.',
        'Lacks official accreditation or verifiable contact information.'
      ];
      if (lower.includes('free money') || lower.includes('urgent') || lower.includes('telegram') || lower.includes('whatsapp') || lower.includes('fee')) {
        status = 'warning';
        title = 'Multiple Warning Signs Detected';
        color = 'red';
        indicators = [
          'High-pressure urgency tactics demanding immediate payment or action.',
          'Unofficial communication channels (Telegram/WhatsApp/Personal Gmail).',
          'Promises guaranteed results or funds with zero verifiable credentials.'
        ];
      } else if (lower.includes('gov') || lower.includes('edu') || lower.includes('official university')) {
        status = 'safe';
        title = 'No Major Red Flags Detected';
        color = 'green';
        indicators = [
          'Domain matches recognized official government or educational institution.',
          'Standard institutional disclosure and transparent terms found.',
          'No request for upfront sensitive banking credentials.'
        ];
      }

      setAnalysisResult({
        claim: claimInput || urlInput,
        category,
        status,
        title,
        color,
        indicators,
        date: new Date().toLocaleDateString()
      });
      setCurrentTab('result');
    }, 1500);
  };

  const scenarios = [
    {
      id: 1,
      title: "The 'Global Tech Grant' Telegram Scholarship",
      level: 'beginner',
      description: "You receive a WhatsApp message stating you won a $5,000 global student grant. The sender asks for a $35 'administrative activation fee' via UPI/Crypto before transfer.",
      options: [
        "Pay the $35 fee immediately since $5,000 is a huge return.",
        "Check official university/scholarship portals, recognize that legitimate scholarships never charge upfront fees, and report the number.",
        "Share your bank PIN so they can deposit the funds directly."
      ],
      correct: 1,
      explanation: "Legitimate scholarships and grants never require upfront fees or activation deposits. This is a classic advance-fee scam."
    },
    {
      id: 2,
      title: "Google Career Certificate for $10 via Direct Link",
      level: 'intermediate',
      description: "An ad on social media offers an official Google IT Support Certificate for $10 instead of standard pricing, leading to 'pay-fast-portal.net'.",
      options: [
        "Buy it quickly before the discount expires.",
        "Verify the domain on official Google Career Certificates / Coursera partner pages. Non-official domains offering steep steep discounts are phishing portals.",
        "Enter your password to link your Google account."
      ],
      correct: 1,
      explanation: "Scammers frequently spin up lookalike domains ('pay-fast-portal.net') mimicking reputable providers to steal credit card information."
    }
  ];

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#1E293B] flex flex-col font-sans">
      
      {/* NAVIGATION BAR */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Logo */}
          <button 
            onClick={() => setCurrentTab('home')}
            className="flex items-center gap-3 text-left group focus:outline-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#102A43] to-[#2563EB] flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
              <ShieldCheck className="w-6 h-6 text-[#14B8A6]" />
            </div>
            <div>
              <span className="text-xl font-extrabold tracking-tight text-[#102A43]">Info<span className="text-[#2563EB]">Sure</span></span>
              <span className="block text-[10px] font-semibold uppercase tracking-wider text-[#14B8A6]">Verify Before You Trust</span>
            </div>
          </button>

          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-8 font-medium text-sm text-[#1E293B]">
            <button onClick={() => setCurrentTab('home')} className={`transition-colors hover:text-[#2563EB] ${currentTab === 'home' ? 'text-[#2563EB] font-semibold' : ''}`}>Home</button>
            <button onClick={() => setCurrentTab('verify')} className={`transition-colors hover:text-[#2563EB] ${currentTab === 'verify' || currentTab === 'result' ? 'text-[#2563EB] font-semibold' : ''}`}>Verify Information</button>
            <button onClick={() => setCurrentTab('learn')} className={`transition-colors hover:text-[#2563EB] ${currentTab === 'learn' ? 'text-[#2563EB] font-semibold' : ''}`}>Learn</button>
            <button onClick={() => setCurrentTab('dashboard')} className={`transition-colors hover:text-[#2563EB] ${currentTab === 'dashboard' ? 'text-[#2563EB] font-semibold' : ''}`}>Dashboard</button>
            <button onClick={() => setCurrentTab('about')} className={`transition-colors hover:text-[#2563EB] ${currentTab === 'about' ? 'text-[#2563EB] font-semibold' : ''}`}>About Us</button>
            <button onClick={() => setCurrentTab('contact')} className={`transition-colors hover:text-[#2563EB] ${currentTab === 'contact' ? 'text-[#2563EB] font-semibold' : ''}`}>Contact</button>
          </nav>

          {/* Action Buttons */}
          <div className="hidden md:flex items-center gap-4">
            <button 
              onClick={() => setCurrentTab('signin')}
              className="text-sm font-semibold text-[#102A43] hover:text-[#2563EB] px-3 py-2"
            >
              Sign In
            </button>
            <button 
              onClick={() => setCurrentTab('verify')}
              className="px-5 py-2.5 rounded-xl bg-[#2563EB] text-white text-sm font-semibold shadow-lg shadow-blue-500/25 hover:bg-blue-700 hover:shadow-xl transition-all flex items-center gap-2"
            >
              <span>Get Started</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg text-slate-700 hover:bg-slate-100 focus:outline-none"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation Dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-b border-slate-200 px-4 pt-2 pb-6 space-y-3 shadow-xl">
            <button onClick={() => { setCurrentTab('home'); setMobileMenuOpen(false); }} className="block w-full text-left py-2 font-medium text-slate-800">Home</button>
            <button onClick={() => { setCurrentTab('verify'); setMobileMenuOpen(false); }} className="block w-full text-left py-2 font-medium text-slate-800">Verify Information</button>
            <button onClick={() => { setCurrentTab('learn'); setMobileMenuOpen(false); }} className="block w-full text-left py-2 font-medium text-slate-800">Learn</button>
            <button onClick={() => { setCurrentTab('dashboard'); setMobileMenuOpen(false); }} className="block w-full text-left py-2 font-medium text-slate-800">Dashboard</button>
            <button onClick={() => { setCurrentTab('about'); setMobileMenuOpen(false); }} className="block w-full text-left py-2 font-medium text-slate-800">About Us</button>
            <button onClick={() => { setCurrentTab('contact'); setMobileMenuOpen(false); }} className="block w-full text-left py-2 font-medium text-slate-800">Contact</button>
            <div className="pt-4 border-t border-slate-100 flex flex-col gap-3">
              <button onClick={() => { setCurrentTab('signin'); setMobileMenuOpen(false); }} className="w-full py-2.5 text-center font-semibold text-[#102A43] border border-slate-200 rounded-xl">Sign In</button>
              <button onClick={() => { setCurrentTab('verify'); setMobileMenuOpen(false); }} className="w-full py-2.5 text-center font-semibold text-white bg-[#2563EB] rounded-xl shadow-md">Get Started</button>
            </div>
          </div>
        )}
      </header>

      {/* MAIN CONTENT CONTAINER */}
      <main className="flex-grow">
        
        {/* 1. LANDING PAGE */}
        {currentTab === 'home' && (
          <div>
            {/* Hero Section */}
            <section className="relative overflow-hidden pt-16 pb-24 lg:pt-24 lg:pb-32 bg-gradient-to-b from-white via-[#F8FAFC] to-[#F8FAFC]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                <div className="grid lg:grid-cols-12 gap-12 items-center">
                  
                  <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
                    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-teal-50 border border-teal-200 text-[#14B8A6] text-xs font-bold uppercase tracking-wider">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Student Digital Literacy & Safety Platform</span>
                    </div>
                    
                    <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-[#102A43] tracking-tight leading-[1.1]">
                      Verify Before <br />
                      <span className="text-[#2563EB]">You Trust.</span>
                    </h1>
                    
                    <p className="text-lg sm:text-xl text-[#1E293B]/80 max-w-2xl mx-auto lg:mx-0 font-normal leading-relaxed">
                      Make smarter decisions online. Check educational offers, identify suspicious claims, and learn how to protect yourself from digital scams with InfoSure.
                    </p>
                    
                    <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-4">
                      <button 
                        onClick={() => setCurrentTab('verify')}
                        className="w-full sm:w-auto px-8 py-4 rounded-xl bg-[#2563EB] text-white font-semibold shadow-lg shadow-blue-500/25 hover:bg-blue-700 hover:shadow-xl transition-all flex items-center justify-center gap-3 text-base"
                      >
                        <Search className="w-5 h-5 text-teal-300" />
                        <span>Verify Information</span>
                      </button>
                      
                      <button 
                        onClick={() => setCurrentTab('learn')}
                        className="w-full sm:w-auto px-8 py-4 rounded-xl bg-white border border-slate-200 text-[#102A43] font-semibold hover:bg-slate-50 shadow-sm transition-all flex items-center justify-center gap-2 text-base"
                      >
                        <BookOpen className="w-5 h-5 text-[#2563EB]" />
                        <span>Learn to Spot Scams</span>
                      </button>
                    </div>

                    <div className="pt-6 flex items-center justify-center lg:justify-start gap-6 text-xs text-slate-500 font-medium">
                      <span className="flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-[#14B8A6]" /> Instant Preliminary Check</span>
                      <span className="flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-[#14B8A6]" /> Official Source Guide</span>
                    </div>
                  </div>

                  {/* Dashboard Preview Illustration */}
                  <div className="lg:col-span-5">
                    <div className="bg-white rounded-2xl shadow-2xl border border-slate-200/80 p-6 relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-teal-500/10 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>
                      
                      <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-red-400"></div>
                          <div className="w-3 h-3 rounded-full bg-amber-400"></div>
                          <div className="w-3 h-3 rounded-full bg-green-400"></div>
                        </div>
                        <span className="text-xs font-mono text-slate-400">InfoSure Engine v1.2</span>
                      </div>

                      <div className="py-5 space-y-4">
                        <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200">
                          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Active Scan Target</span>
                          <p className="text-xs font-mono text-[#102A43] truncate">https://scholarship-grant-winners-2026.net</p>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-center">
                            <span className="block text-[10px] font-bold text-amber-700 uppercase">Assessment</span>
                            <span className="text-xs font-bold text-amber-800">Needs Verification</span>
                          </div>
                          <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-center">
                            <span className="block text-[10px] font-bold text-red-700 uppercase">Red Flags</span>
                            <span className="text-xs font-bold text-red-800">3 Warnings Found</span>
                          </div>
                        </div>

                        <div className="space-y-2 pt-2">
                          <div className="flex items-center justify-between text-xs text-slate-600 bg-slate-50 p-2.5 rounded-lg">
                            <span className="flex items-center gap-2"><AlertTriangle className="w-3.5 h-3.5 text-amber-600" /> Upfront Fee Requested</span>
                            <span className="font-semibold text-amber-600">High Risk</span>
                          </div>
                          <div className="flex items-center justify-between text-xs text-slate-600 bg-slate-50 p-2.5 rounded-lg">
                            <span className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-[#14B8A6]" /> Official Registry Match</span>
                            <span className="font-semibold text-[#14B8A6]">Verified</span>
                          </div>
                        </div>
                      </div>

                      <button 
                        onClick={() => setCurrentTab('verify')}
                        className="w-full py-3 rounded-xl bg-[#102A43] text-white text-xs font-semibold hover:bg-[#2563EB] transition-colors flex items-center justify-center gap-2 shadow-sm"
                      >
                        <span>Run New Verification Scan</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                </div>
              </div>
            </section>

            {/* Trust Section */}
            <section className="py-16 bg-white border-y border-slate-200">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                <span className="text-xs font-bold uppercase tracking-widest text-[#14B8A6]">Reliable Protection</span>
                <h2 className="text-3xl font-extrabold text-[#102A43] mt-2 mb-4">Your first step toward safer online decisions.</h2>
                <p className="text-slate-600 max-w-2xl mx-auto mb-12">
                  Designed specifically for students, parents, and job seekers navigating a crowded and sometimes deceptive digital ecosystem.
                </p>

                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                  <div className="bg-[#F8FAFC] p-6 rounded-2xl border border-slate-200/80 text-left hover:shadow-lg transition-shadow">
                    <div className="w-12 h-12 rounded-xl bg-blue-50 text-[#2563EB] flex items-center justify-center mb-4">
                      <Sparkles className="w-6 h-6" />
                    </div>
                    <h3 className="font-bold text-[#102A43] text-lg mb-2">1. AI-Assisted Analysis</h3>
                    <p className="text-sm text-slate-600">Preliminary rule-based and language inspection to highlight potential scam patterns instantly.</p>
                  </div>

                  <div className="bg-[#F8FAFC] p-6 rounded-2xl border border-slate-200/80 text-left hover:shadow-lg transition-shadow">
                    <div className="w-12 h-12 rounded-xl bg-teal-50 text-[#14B8A6] flex items-center justify-center mb-4">
                      <Award className="w-6 h-6" />
                    </div>
                    <h3 className="font-bold text-[#102A43] text-lg mb-2">2. Offer Verification</h3>
                    <p className="text-sm text-slate-600">Evaluate online courses, scholarships, internships, and job postings before investing your time and money.</p>
                  </div>

                  <div className="bg-[#F8FAFC] p-6 rounded-2xl border border-slate-200/80 text-left hover:shadow-lg transition-shadow">
                    <div className="w-12 h-12 rounded-xl bg-blue-50 text-[#2563EB] flex items-center justify-center mb-4">
                      <BookOpen className="w-6 h-6" />
                    </div>
                    <h3 className="font-bold text-[#102A43] text-lg mb-2">3. Scam Awareness Training</h3>
                    <p className="text-sm text-slate-600">Interactive scenarios and quizzes to build permanent digital literacy and threat-spotting intuition.</p>
                  </div>

                  <div className="bg-[#F8FAFC] p-6 rounded-2xl border border-slate-200/80 text-left hover:shadow-lg transition-shadow">
                    <div className="w-12 h-12 rounded-xl bg-teal-50 text-[#14B8A6] flex items-center justify-center mb-4">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <h3 className="font-bold text-[#102A43] text-lg mb-2">4. Official Source Checking</h3>
                    <p className="text-sm text-slate-600">Direct pathways to verified registries, government education portals, and authentic domain channels.</p>
                  </div>
                </div>
              </div>
            </section>

            {/* Think Before You Trust Section & 3-Step Process */}
            <section className="py-20 bg-[#F8FAFC]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center max-w-3xl mx-auto mb-16">
                  <h2 className="text-3xl font-extrabold text-[#102A43]">Think Before You Trust</h2>
                  <p className="text-slate-600 mt-3">
                    Evaluate suspicious messages, scholarship offers, course advertisements, internship opportunities, and educational announcements in three simple steps.
                  </p>
                </div>

                <div className="grid md:grid-cols-3 gap-8">
                  <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm relative">
                    <div className="w-10 h-10 rounded-full bg-[#2563EB] text-white font-bold flex items-center justify-center mb-6 text-sm">01</div>
                    <h3 className="text-xl font-bold text-[#102A43] mb-3">Submit the Information</h3>
                    <p className="text-slate-600 text-sm leading-relaxed">
                      Paste the suspicious message, offer text, website URL, or job announcement into the InfoSure verification engine.
                    </p>
                  </div>

                  <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm relative">
                    <div className="w-10 h-10 rounded-full bg-[#14B8A6] text-white font-bold flex items-center justify-center mb-6 text-sm">02</div>
                    <h3 className="text-xl font-bold text-[#102A43] mb-3">Review Analysis & Evidence</h3>
                    <p className="text-slate-600 text-sm leading-relaxed">
                      Examine identified risk indicators, warning signs, domain credibility, and suggested safety checks.
                    </p>
                  </div>

                  <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm relative">
                    <div className="w-10 h-10 rounded-full bg-[#102A43] text-white font-bold flex items-center justify-center mb-6 text-sm">03</div>
                    <h3 className="text-xl font-bold text-[#102A43] mb-3">Verify via Official Sources</h3>
                    <p className="text-slate-600 text-sm leading-relaxed">
                      Cross-reference findings with official government registries and accredited educational portals before taking action.
                    </p>
                  </div>
                </div>

                <div className="mt-12 text-center">
                  <button 
                    onClick={() => setCurrentTab('verify')}
                    className="px-8 py-4 rounded-xl bg-[#102A43] text-white font-semibold hover:bg-[#2563EB] transition-colors shadow-lg inline-flex items-center gap-3"
                  >
                    <span>Start Verifying Now</span>
                    <ArrowRight className="w-5 h-5 text-[#14B8A6]" />
                  </button>
                </div>
              </div>
            </section>
          </div>
        )}

        {/* 2. INFORMATION VERIFICATION DASHBOARD */}
        {currentTab === 'verify' && (
          <div className="py-12 bg-[#F8FAFC]">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
              
              <div className="text-center mb-10">
                <span className="text-xs font-bold text-[#14B8A6] uppercase tracking-widest">Verification Engine</span>
                <h1 className="text-3xl font-extrabold text-[#102A43] mt-2">Information Verification Dashboard</h1>
                <p className="text-slate-600 mt-2">
                  Submit suspicious educational offers, links, or messages to receive an instant preliminary safety analysis.
                </p>
              </div>

              <div className="bg-white rounded-2xl shadow-xl border border-slate-200 p-8">
                <form onSubmit={handleAnalyze} className="space-y-6">
                  
                  <div>
                    <label className="block text-sm font-bold text-[#102A43] mb-2">
                      Suspicious Message or Claim Text
                    </label>
                    <textarea 
                      rows={3}
                      value={claimInput}
                      onChange={(e) => setClaimInput(e.target.value)}
                      placeholder="Paste text here e.g., 'Congratulations! You won a $5000 grant. Pay $20 to claim...'"
                      className="w-full rounded-xl border border-slate-300 p-4 text-sm focus:ring-2 focus:ring-[#2563EB] focus:outline-none"
                    ></textarea>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-[#102A43] mb-2">
                        Website URL or Offer Link (Optional)
                      </label>
                      <input 
                        type="text"
                        value={urlInput}
                        onChange={(e) => setUrlInput(e.target.value)}
                        placeholder="https://example-scholarship.net"
                        className="w-full rounded-xl border border-slate-300 p-3.5 text-sm focus:ring-2 focus:ring-[#2563EB] focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-[#102A43] mb-2">
                        Category Selector
                      </label>
                      <select 
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full rounded-xl border border-slate-300 p-3.5 text-sm bg-white focus:ring-2 focus:ring-[#2563EB] focus:outline-none"
                      >
                        <option>Scholarship</option>
                        <option>Online Course</option>
                        <option>Internship</option>
                        <option>Job Offer</option>
                        <option>Certificate</option>
                        <option>Exam Notification</option>
                        <option>Educational Institution</option>
                        <option>Other</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-[#102A43] mb-2">
                      Optional Context / Notes
                    </label>
                    <input 
                      type="text"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="e.g., Received via WhatsApp from an unknown number"
                      className="w-full rounded-xl border border-slate-300 p-3.5 text-sm focus:ring-2 focus:ring-[#2563EB] focus:outline-none"
                    />
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-xs text-slate-500 font-medium">
                      🔒 Demo Mode Active: Analysis is rule-based and privacy-safe.
                    </span>

                    <button 
                      type="submit"
                      disabled={isAnalyzing}
                      className="px-8 py-4 rounded-xl bg-[#2563EB] text-white font-semibold shadow-lg shadow-blue-500/25 hover:bg-blue-700 transition-all flex items-center gap-3 disabled:opacity-50"
                    >
                      {isAnalyzing ? (
                        <>
                          <RefreshCw className="w-5 h-5 animate-spin" />
                          <span>Analyzing Claim...</span>
                        </>
                      ) : (
                        <>
                          <Search className="w-5 h-5 text-teal-300" />
                          <span>Analyze Information</span>
                        </>
                      )}
                    </button>
                  </div>

                </form>
              </div>

              <div className="mt-8 bg-amber-50 border border-amber-200 rounded-2xl p-6 text-amber-900 text-xs sm:text-sm leading-relaxed">
                <span className="font-bold block mb-1">Disclaimer Notice:</span>
                InfoSure provides preliminary information and educational guidance. Results are not guarantees of authenticity or fraud. Always verify important claims through official sources.
              </div>

            </div>
          </div>
        )}

        {/* 3. VERIFICATION RESULT PAGE */}
        {currentTab === 'result' && analysisResult && (
          <div className="py-12 bg-[#F8FAFC]">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
              
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-[#14B8A6] uppercase tracking-wider">Analysis Report</span>
                  <h1 className="text-3xl font-extrabold text-[#102A43] mt-1">Verification Assessment</h1>
                </div>
                <button 
                  onClick={() => setCurrentTab('verify')}
                  className="px-4 py-2 rounded-xl bg-slate-200 text-[#102A43] font-semibold text-sm hover:bg-slate-300 transition-colors"
                >
                  New Analysis
                </button>
              </div>

              {/* Status Banner */}
              <div className={`p-6 rounded-2xl border flex items-center gap-4 ${
                analysisResult.color === 'red' ? 'bg-red-50 border-red-200 text-red-900' :
                analysisResult.color === 'amber' ? 'bg-amber-50 border-amber-200 text-amber-900' :
                'bg-green-50 border-green-200 text-green-900'
              }`}>
                {analysisResult.color === 'red' ? <AlertOctagon className="w-10 h-10 text-red-600 flex-shrink-0" /> :
                 analysisResult.color === 'amber' ? <AlertTriangle className="w-10 h-10 text-amber-600 flex-shrink-0" /> :
                 <CheckCircle2 className="w-10 h-10 text-green-600 flex-shrink-0" />}
                <div>
                  <h2 className="text-xl font-bold">{analysisResult.title}</h2>
                  <p className="text-xs sm:text-sm opacity-90 mt-1">Category: {analysisResult.category} • Analyzed on {analysisResult.date}</p>
                </div>
              </div>

              {/* Report Details Card */}
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 space-y-6">
                <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Submitted Claim / URL</h3>
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 font-mono text-xs text-[#102A43] break-all">
                    {analysisResult.claim}
                  </div>
                </div>

                <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Risk Indicators Identified</h3>
                  <div className="space-y-3">
                    {analysisResult.indicators.map((ind: string, idx: number) => (
                      <div key={idx} className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                        {analysisResult.color === 'red' ? <AlertTriangle className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" /> :
                         <AlertTriangle className="w-5 h-5 text-amber-500 mt-0.5 flex-shrink-0" />}
                        <span className="text-sm text-slate-700">{ind}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Source Verification Checklist</h3>
                  <div className="space-y-2 text-sm text-slate-700">
                    <div className="flex items-center gap-2"><Check className="w-4 h-4 text-[#14B8A6]" /> Check domain registration details on ICANN WHOIS</div>
                    <div className="flex items-center gap-2"><Check className="w-4 h-4 text-[#14B8A6]" /> Cross-reference with official institution website (.edu / .gov)</div>
                    <div className="flex items-center gap-2"><Check className="w-4 h-4 text-[#14B8A6]" /> Confirm whether any upfront payment is requested</div>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-100 flex flex-wrap gap-4 items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button 
                      onClick={() => alert('Report copied to clipboard!')}
                      className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-sm font-semibold hover:bg-slate-50 flex items-center gap-2"
                    >
                      <Copy className="w-4 h-4" />
                      <span>Copy Report</span>
                    </button>
                    <button 
                      onClick={() => alert('PDF report download simulated successfully!')}
                      className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-sm font-semibold hover:bg-slate-50 flex items-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      <span>Download PDF</span>
                    </button>
                  </div>

                  <button 
                    onClick={() => setCurrentTab('verify')}
                    className="px-6 py-2.5 rounded-xl bg-[#2563EB] text-white text-sm font-semibold hover:bg-blue-700 shadow-md"
                  >
                    Submit Another Claim
                  </button>
                </div>
              </div>

              {/* Feedback Section */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center space-y-3">
                <h4 className="font-bold text-[#102A43]">Was this analysis helpful?</h4>
                <div className="flex justify-center gap-3">
                  <button onClick={() => alert('Thank you for your feedback!')} className="px-6 py-2 rounded-xl bg-slate-100 font-semibold text-sm hover:bg-slate-200">Yes 👍</button>
                  <button onClick={() => alert('Thank you for your feedback!')} className="px-6 py-2 rounded-xl bg-slate-100 font-semibold text-sm hover:bg-slate-200">Needs Improvement 👎</button>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* 4. SCAM AWARENESS LEARNING CENTER */}
        {currentTab === 'learn' && (
          <div className="py-12 bg-[#F8FAFC]">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
              
              <div className="text-center">
                <span className="text-xs font-bold text-[#14B8A6] uppercase tracking-wider">Educational Training</span>
                <h1 className="text-3xl font-extrabold text-[#102A43] mt-2">Learn to Spot the Red Flags</h1>
                <p className="text-slate-600 mt-2">
                  Test your threat-spotting skills against realistic student scam scenarios.
                </p>
              </div>

              {/* Quiz progress / stats */}
              <div className="grid sm:grid-cols-3 gap-4">
                <div className="bg-white p-5 rounded-2xl border border-slate-200 text-center">
                  <span className="block text-xs font-bold text-slate-400 uppercase">Current Score</span>
                  <span className="text-2xl font-extrabold text-[#2563EB]">{quizScore} / 2</span>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-slate-200 text-center">
                  <span className="block text-xs font-bold text-slate-400 uppercase">Difficulty Level</span>
                  <span className="text-2xl font-extrabold text-[#14B8A6] capitalize">{difficulty}</span>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-slate-200 text-center">
                  <span className="block text-xs font-bold text-slate-400 uppercase">Training Status</span>
                  <span className="text-2xl font-extrabold text-[#102A43]">Active</span>
                </div>
              </div>

              {/* Scenarios List */}
              <div className="space-y-6">
                {scenarios.map((scen) => (
                  <div key={scen.id} className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm space-y-6">
                    <div className="flex items-center justify-between">
                      <span className="px-3 py-1 rounded-full bg-blue-50 text-[#2563EB] text-xs font-bold uppercase">Scenario #{scen.id} • {scen.level}</span>
                      <span className="text-xs font-semibold text-amber-700 bg-amber-50 px-3 py-1 rounded-full">Fraining Example</span>
                    </div>

                    <h3 className="text-xl font-bold text-[#102A43]">{scen.title}</h3>
                    <p className="text-slate-700 text-sm leading-relaxed">{scen.description}</p>

                    <div className="space-y-3">
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Choose the safest action:</span>
                      {scen.options.map((opt, idx) => (
                        <button
                          key={idx}
                          onClick={() => {
                            setSelectedScenario(scen.id);
                            setSelectedAnswer(idx);
                          }}
                          className={`w-full text-left p-4 rounded-xl border text-sm font-medium transition-all ${
                            selectedScenario === scen.id && selectedAnswer === idx ? 
                            (idx === scen.correct ? 'bg-green-50 border-green-300 text-green-900 font-bold' : 'bg-red-50 border-red-300 text-red-900 font-bold') :
                            'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-800'
                          }`}
                        >
                          {String.fromCharCode(65 + idx)}. {opt}
                        </button>
                      ))}
                    </div>

                    {selectedScenario === scen.id && selectedAnswer !== null && (
                      <div className={`p-4 rounded-xl border ${selectedAnswer === scen.correct ? 'bg-green-50 border-green-200 text-green-900' : 'bg-red-50 border-red-200 text-red-900'}`}>
                        <p className="font-bold text-sm mb-1">
                          {selectedAnswer === scen.correct ? '✅ Correct Answer!' : '❌ Incorrect. Review why:'}
                        </p>
                        <p className="text-xs leading-relaxed">{scen.explanation}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>

            </div>
          </div>
        )}

        {/* 5. USER DASHBOARD */}
        {currentTab === 'dashboard' && (
          <div className="py-12 bg-[#F8FAFC]">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
              
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <span className="text-xs font-bold text-[#14B8A6] uppercase tracking-wider">Demo User Portal</span>
                  <h1 className="text-3xl font-extrabold text-[#102A43] mt-1">Welcome, Student Scholar</h1>
                </div>
                <button 
                  onClick={() => setCurrentTab('verify')}
                  className="px-5 py-2.5 rounded-xl bg-[#2563EB] text-white text-sm font-semibold shadow-md hover:bg-blue-700"
                >
                  + New Verification
                </button>
              </div>

              {/* Stats Overview */}
              <div className="grid sm:grid-cols-4 gap-6">
                <div className="bg-white p-6 rounded-2xl border border-slate-200">
                  <span className="text-xs font-bold text-slate-400 uppercase">Analyses Performed</span>
                  <span className="text-3xl font-extrabold text-[#102A43] mt-2 block">12</span>
                </div>
                <div className="bg-white p-6 rounded-2xl border border-slate-200">
                  <span className="text-xs font-bold text-slate-400 uppercase">Scams Prevented</span>
                  <span className="text-3xl font-extrabold text-[#14B8A6] mt-2 block">4</span>
                </div>
                <div className="bg-white p-6 rounded-2xl border border-slate-200">
                  <span className="text-xs font-bold text-slate-400 uppercase">Quiz Score</span>
                  <span className="text-3xl font-extrabold text-[#2563EB] mt-2 block">94%</span>
                </div>
                <div className="bg-white p-6 rounded-2xl border border-slate-200">
                  <span className="text-xs font-bold text-slate-400 uppercase">Saved Reports</span>
                  <span className="text-3xl font-extrabold text-[#102A43] mt-2 block">5</span>
                </div>
              </div>

              {/* Recent Verification History */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-6">
                <h3 className="text-lg font-bold text-[#102A43]">Recent Verification History</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-200 text-sm">
                    <div className="flex items-center gap-3">
                      <AlertTriangle className="w-5 h-5 text-amber-500" />
                      <div>
                        <span className="font-semibold text-[#102A43] block">scholarship-grant-2026.net</span>
                        <span className="text-xs text-slate-500">Scholarship • Needs Verification</span>
                      </div>
                    </div>
                    <span className="text-xs text-slate-400">Oct 23, 2026</span>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-200 text-sm">
                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 text-[#14B8A6]" />
                      <div>
                        <span className="font-semibold text-[#102A43] block">coursera.org/professional-certificate</span>
                        <span className="text-xs text-slate-500">Online Course • Verified</span>
                      </div>
                    </div>
                    <span className="text-xs text-slate-400">Oct 21, 2026</span>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* 7. ABOUT INFOSURE */}
        {currentTab === 'about' && (
          <div className="py-16 bg-[#F8FAFC]">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
              
              <div className="text-center space-y-4">
                <span className="text-xs font-bold text-[#14B8A6] uppercase tracking-wider">About InfoSure</span>
                <h1 className="text-4xl font-extrabold text-[#102A43]">Empowering Students Online</h1>
                <p className="text-slate-600 max-w-2xl mx-auto text-lg leading-relaxed">
                  InfoSure was built to protect students, job seekers, and online learners from digital scams, fraudulent scholarships, and misleading educational offers.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                  <h3 className="text-xl font-bold text-[#102A43]">Our Mission</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    "To empower students with the knowledge and tools they need to evaluate online educational information and recognize potential digital scams."
                  </p>
                </div>

                <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                  <h3 className="text-xl font-bold text-[#102A43]">Our Vision</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    "A digital environment where students can make informed, confident decisions about educational and career opportunities."
                  </p>
                </div>
              </div>

              <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm space-y-6">
                <h3 className="text-xl font-bold text-[#102A43]">Core Values</h3>
                <div className="grid sm:grid-cols-3 gap-6">
                  <div>
                    <h4 className="font-bold text-[#2563EB] mb-1">Transparency</h4>
                    <p className="text-xs text-slate-600">Clear disclaimers, rule-based assessments, and verifiable references.</p>
                  </div>
                  <div>
                    <h4 className="font-bold text-[#2563EB] mb-1">Digital Literacy</h4>
                    <p className="text-xs text-slate-600">Equipping students with permanent threat-spotting skills.</p>
                  </div>
                  <div>
                    <h4 className="font-bold text-[#2563EB] mb-1">Student Safety</h4>
                    <p className="text-xs text-slate-600">Prioritizing privacy and online security in all features.</p>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* 8. CONTACT AND FEEDBACK */}
        {currentTab === 'contact' && (
          <div className="py-16 bg-[#F8FAFC]">
            <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
              
              <div className="text-center">
                <span className="text-xs font-bold text-[#14B8A6] uppercase tracking-wider">Get in Touch</span>
                <h1 className="text-3xl font-extrabold text-[#102A43] mt-2">Contact InfoSure Support</h1>
                <p className="text-slate-600 mt-2">Have feedback or want to report a new scam pattern? Reach out to our team.</p>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm">
                {contactSubmitted ? (
                  <div className="text-center py-8 space-y-4">
                    <CheckCircle2 className="w-16 h-16 text-[#14B8A6] mx-auto" />
                    <h3 className="text-2xl font-bold text-[#102A43]">Message Received</h3>
                    <p className="text-slate-600 text-sm">Thank you for reaching out. In demo mode, your message has been logged locally.</p>
                    <button onClick={() => setContactSubmitted(false)} className="px-6 py-2.5 rounded-xl bg-[#2563EB] text-white font-semibold text-sm">Send Another</button>
                  </div>
                ) : (
                  <form onSubmit={(e) => { e.preventDefault(); setContactSubmitted(true); }} className="space-y-6">
                    <div>
                      <label className="block text-sm font-bold text-[#102A43] mb-2">Your Name</label>
                      <input type="text" required placeholder="Alex Johnson" className="w-full rounded-xl border border-slate-300 p-3.5 text-sm focus:ring-2 focus:ring-[#2563EB] focus:outline-none" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-[#102A43] mb-2">Email Address</label>
                      <input type="email" required placeholder="alex@university.edu" className="w-full rounded-xl border border-slate-300 p-3.5 text-sm focus:ring-2 focus:ring-[#2563EB] focus:outline-none" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-[#102A43] mb-2">Subject</label>
                      <input type="text" required placeholder="Reporting a fake scholarship link" className="w-full rounded-xl border border-slate-300 p-3.5 text-sm focus:ring-2 focus:ring-[#2563EB] focus:outline-none" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-[#102A43] mb-2">Message</label>
                      <textarea rows={4} required placeholder="Provide details here..." className="w-full rounded-xl border border-slate-300 p-4 text-sm focus:ring-2 focus:ring-[#2563EB] focus:outline-none"></textarea>
                    </div>
                    <button type="submit" className="w-full py-4 rounded-xl bg-[#2563EB] text-white font-semibold shadow-lg hover:bg-blue-700 transition-colors">
                      Send Message
                    </button>
                  </form>
                )}
              </div>

            </div>
          </div>
        )}

        {/* 6. AUTHENTICATION & SIGN IN */}
        {currentTab === 'signin' && (
          <div className="py-16 bg-[#F8FAFC]">
            <div className="max-w-md mx-auto px-4">
              <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-xl space-y-6">
                <div className="text-center space-y-2">
                  <div className="w-12 h-12 rounded-xl bg-blue-50 text-[#2563EB] flex items-center justify-center mx-auto mb-4">
                    <Lock className="w-6 h-6" />
                  </div>
                  <h1 className="text-2xl font-extrabold text-[#102A43]">Sign In to InfoSure</h1>
                  <p className="text-xs text-slate-500">Access saved verification history and quiz progress in demo mode.</p>
                </div>

                <form onSubmit={(e) => { e.preventDefault(); setIsLoggedIn(true); setCurrentTab('dashboard'); }} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-[#102A43] mb-1">Email Address</label>
                    <input type="email" required value={authEmail} onChange={(e) => setAuthEmail(e.target.value)} placeholder="student@university.edu" className="w-full rounded-xl border border-slate-300 p-3 text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-[#102A43] mb-1">Password</label>
                    <input type="password" required value={authPassword} onChange={(e) => setAuthPassword(e.target.value)} placeholder="••••••••" className="w-full rounded-xl border border-slate-300 p-3 text-sm" />
                  </div>
                  <button type="submit" className="w-full py-3.5 rounded-xl bg-[#2563EB] text-white font-semibold text-sm shadow-md hover:bg-blue-700">
                    Sign In (Demo Mode)
                  </button>
                </form>
              </div>
            </div>
          </div>
        )}

      </main>

      {/* FOOTER */}
      <footer className="bg-[#102A43] text-white pt-16 pb-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-4 gap-10 mb-12">
          
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#2563EB] flex items-center justify-center text-white">
                <ShieldCheck className="w-5 h-5 text-[#14B8A6]" />
              </div>
              <span className="text-lg font-bold tracking-tight">InfoSure</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Verify Before You Trust. Empowering students and online learners with digital literacy and preliminary scam detection tools.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-sm mb-4 text-slate-200">Quick Links</h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li><button onClick={() => setCurrentTab('home')} className="hover:text-white">Home</button></li>
              <li><button onClick={() => setCurrentTab('verify')} className="hover:text-white">Verify Information</button></li>
              <li><button onClick={() => setCurrentTab('learn')} className="hover:text-white">Learning Center</button></li>
              <li><button onClick={() => setCurrentTab('dashboard')} className="hover:text-white">User Dashboard</button></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-sm mb-4 text-slate-200">Safety & Legal</h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li><button onClick={() => setCurrentTab('about')} className="hover:text-white">About Us</button></li>
              <li><button onClick={() => setCurrentTab('contact')} className="hover:text-white">Contact & Support</button></li>
              <li><span className="hover:text-white cursor-pointer">Privacy Policy</span></li>
              <li><span className="hover:text-white cursor-pointer">Terms of Use</span></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-sm mb-4 text-slate-200">Stay Protected</h4>
            <p className="text-xs text-slate-400 mb-3">Subscribe for monthly student scam alerts and digital safety guides.</p>
            <div className="flex gap-2">
              <input type="email" placeholder="Your email" className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white w-full focus:outline-none" />
              <button onClick={() => alert('Subscribed successfully!')} className="bg-[#2563EB] text-white px-4 py-2 rounded-xl text-xs font-semibold hover:bg-blue-600">Join</button>
            </div>
          </div>

        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 border-t border-slate-800 text-center text-xs text-slate-500">
          © 2026 InfoSure. All rights reserved. Built for student digital literacy and safety.
        </div>
      </footer>

    </div>
  );
}
